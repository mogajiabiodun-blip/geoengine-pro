const express = require('express');
const { PrismaClient } = require('@prisma/client');

const prisma = new PrismaClient();
const router = express.Router();

/**
 * @swagger
 * /export/{projectId}:
 *   get:
 *     summary: Export project data as GeoJSON
 *     tags: [Export]
 */
router.get('/:projectId', async (req, res, next) => {
  try {
    const { format = 'geojson' } = req.query;

    const project = await prisma.project.findUnique({
      where: { id: req.params.projectId },
      include: {
        layers: {
          where: { visible: true },
          orderBy: { order: 'asc' },
        },
      },
    });

    if (!project) {
      return res.status(404).json({ error: 'Project not found' });
    }

    if (!project.isPublic && project.ownerId !== req.user.id) {
      return res.status(403).json({ error: 'Access denied' });
    }

    // Combine all layer data into a single GeoJSON FeatureCollection
    const features = [];
    project.layers.forEach((layer) => {
      if (layer.data && layer.data.type === 'FeatureCollection') {
        features.push(...layer.data.features);
      } else if (layer.data && layer.data.type === 'Feature') {
        features.push(layer.data);
      }
    });

    const exportData = {
      type: 'FeatureCollection',
      properties: {
        projectName: project.name,
        exportedAt: new Date().toISOString(),
      },
      features,
    };

    if (format === 'geojson') {
      res.setHeader('Content-Type', 'application/json');
      res.setHeader('Content-Disposition', `attachment; filename="${project.name}.geojson"`);
      return res.json(exportData);
    }

    // CSV format (simplified - points only)
    if (format === 'csv') {
      const headers = 'name,longitude,latitude,properties\n';
      const rows = features
        .map((f) => {
          const coords = f.geometry?.coordinates || [];
          const lng = coords[0] || '';
          const lat = coords[1] || '';
          const props = JSON.stringify(f.properties || {}).replace(/"/g, '""');
          return `"${f.properties?.name || ''}",${lng},${lat},"${props}"`;
        })
        .join('\n');

      res.setHeader('Content-Type', 'text/csv');
      res.setHeader('Content-Disposition', `attachment; filename="${project.name}.csv"`);
      return res.send(headers + rows);
    }

    res.json(exportData);
  } catch (error) {
    next(error);
  }
});

module.exports = router;
