const express = require('express');
const multer = require('multer');
const { v4: uuidv4 } = require('uuid');
const path = require('path');
const { PrismaClient } = require('@prisma/client');

const prisma = new PrismaClient();
const router = express.Router();

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, './uploads');
  },
  filename: (req, file, cb) => {
    const uniqueName = `${uuidv4()}${path.extname(file.originalname)}`;
    cb(null, uniqueName);
  },
});

const upload = multer({
  storage,
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB
  fileFilter: (req, file, cb) => {
    const allowedTypes = ['.geojson', '.kml', '.zip', '.csv', '.json'];
    const ext = path.extname(file.originalname).toLowerCase();
    if (allowedTypes.includes(ext)) {
      cb(null, true);
    } else {
      cb(new Error('Invalid file type. Allowed: GeoJSON, KML, Shapefile (ZIP), CSV'));
    }
  },
});

/**
 * @swagger
 * /layers:
 *   get:
 *     summary: Get all layers for a project
 *     tags: [Layers]
 */
router.get('/', async (req, res, next) => {
  try {
    const { projectId } = req.query;
    if (!projectId) {
      return res.status(400).json({ error: 'projectId is required' });
    }

    const layers = await prisma.layer.findMany({
      where: { projectId },
      orderBy: { order: 'asc' },
      include: {
        uploader: { select: { id: true, name: true } },
      },
    });

    res.json({ data: layers });
  } catch (error) {
    next(error);
  }
});

/**
 * @swagger
 * /layers:
 *   post:
 *     summary: Upload a new layer
 *     tags: [Layers]
 */
router.post('/', upload.single('file'), async (req, res, next) => {
  try {
    const { projectId, name, type } = req.body;
    
    if (!projectId || !name || !type) {
      return res.status(400).json({ error: 'projectId, name, and type are required' });
    }

    let data = null;
    let source = 'manual';

    if (req.file) {
      source = req.file.path;
      // Parse file based on extension
      const ext = path.extname(req.file.originalname).toLowerCase();
      if (ext === '.geojson' || ext === '.json') {
        const fs = require('fs');
        const raw = fs.readFileSync(req.file.path, 'utf8');
        data = JSON.parse(raw);
      }
    } else if (req.body.data) {
      data = JSON.parse(req.body.data);
    }

    const maxOrder = await prisma.layer.aggregate({
      where: { projectId },
      _max: { order: true },
    });

    const layer = await prisma.layer.create({
      data: {
        name,
        type: type.toUpperCase(),
        source,
        data: data || undefined,
        style: req.body.style ? JSON.parse(req.body.style) : {},
        projectId,
        uploadedBy: req.user.id,
        order: (maxOrder._max.order || 0) + 1,
      },
      include: {
        uploader: { select: { id: true, name: true } },
      },
    });

    res.status(201).json(layer);
  } catch (error) {
    next(error);
  }
});

/**
 * @swagger
 * /layers/{id}:
 *   put:
 *     summary: Update layer
 *     tags: [Layers]
 */
router.put('/:id', async (req, res, next) => {
  try {
    const { name, style, visible, opacity, order } = req.body;
    
    const layer = await prisma.layer.update({
      where: { id: req.params.id },
      data: {
        ...(name && { name }),
        ...(style && { style }),
        ...(visible !== undefined && { visible }),
        ...(opacity !== undefined && { opacity }),
        ...(order !== undefined && { order }),
      },
    });

    res.json(layer);
  } catch (error) {
    next(error);
  }
});

/**
 * @swagger
 * /layers/{id}:
 *   delete:
 *     summary: Delete layer
 *     tags: [Layers]
 */
router.delete('/:id', async (req, res, next) => {
  try {
    await prisma.layer.delete({ where: { id: req.params.id } });
    res.json({ message: 'Layer deleted successfully' });
  } catch (error) {
    next(error);
  }
});

module.exports = router;
