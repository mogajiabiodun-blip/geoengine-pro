const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

async function main() {
  console.log('Start seeding...');

  // Create sample users
  const user1 = await prisma.user.create({
    data: {
      email: 'admin@geoengine.com',
      name: 'Admin User',
      role: 'ADMIN',
      password: '$2a$10$YourHashedPasswordHere', // In production, use bcrypt
    },
  });

  const user2 = await prisma.user.create({
    data: {
      email: 'demo@geoengine.com',
      name: 'Demo User',
      role: 'USER',
      password: '$2a$10$YourHashedPasswordHere',
    },
  });

  // Create sample projects
  const project1 = await prisma.project.create({
    data: {
      name: 'Urban Planning Analysis',
      description: 'A comprehensive analysis of urban development patterns.',
      centerLng: -74.006,
      centerLat: 40.7128,
      zoom: 12,
      ownerId: user1.id,
      layers: {
        create: [
          {
            name: 'Building Footprints',
            type: 'POLYGON',
            source: 'geojson',
            data: { type: 'FeatureCollection', features: [] },
            style: { fillColor: '#3b82f6', fillOpacity: 0.6 },
            uploadedBy: user1.id,
          },
          {
            name: 'Road Network',
            type: 'LINE',
            source: 'geojson',
            data: { type: 'FeatureCollection', features: [] },
            style: { lineColor: '#f97316', lineWidth: 2 },
            uploadedBy: user1.id,
          },
        ],
      },
    },
  });

  const project2 = await prisma.project.create({
    data: {
      name: 'Environmental Monitoring',
      description: 'Tracking environmental changes across regions.',
      centerLng: 139.6917,
      centerLat: 35.6895,
      zoom: 10,
      isPublic: true,
      ownerId: user2.id,
      layers: {
        create: [
          {
            name: 'Vegetation Index',
            type: 'RASTER',
            source: 'wms',
            data: { url: 'https://example.com/wms' },
            style: { opacity: 0.8 },
            uploadedBy: user2.id,
          },
        ],
      },
    },
  });

  console.log('Seeding finished.');
  console.log({ user1, user2, project1, project2 });
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
