# GeoEngine Pro

A professional geospatial analytics and visualization platform built with Next.js, Node.js, and Mapbox.

## Features
- Interactive 2D/3D map visualization
- Real-time geospatial analytics
- Layer management and export tools
- Spatial analysis and query tools
- Collaborative project sharing
- JWT authentication & OAuth support
- Role-based access control

## Tech Stack
- **Frontend**: Next.js 14, TypeScript, Mapbox GL JS, Tailwind CSS, shadcn/ui
- **Backend**: Node.js, Express, Prisma ORM, PostgreSQL + PostGIS
- **Caching**: Redis
- **Auth**: JWT + OAuth 2.0
- **Testing**: Jest, Cypress
- **DevOps**: Docker, GitHub Actions

## Project Structure

```
geoengine-pro/
├── backend/                 # Express API server
│   ├── prisma/             # Database schema & migrations
│   ├── src/
│   │   ├── routes/         # API routes
│   │   ├── controllers/    # Business logic
│   │   ├── middleware/     # Auth, validation, error handling
│   │   ├── services/       # External services
│   │   └── utils/          # Helpers & utilities
│   ├── tests/              # Unit & integration tests
│   └── server.js           # Entry point
├── frontend/                # Next.js application
│   ├── src/
│   │   ├── app/            # App router pages
│   │   ├── components/     # React components
│   │   ├── hooks/          # Custom React hooks
│   │   ├── lib/            # Utilities & API clients
│   │   └── types/          # TypeScript definitions
│   ├── public/             # Static assets
│   └── next.config.js
├── docker-compose.yml      # Local development stack
├── .github/                # GitHub Actions workflows
└── README.md
```

## Getting Started

### Prerequisites
- Node.js 18+ 
- PostgreSQL 15+ with PostGIS extension
- Redis 7+
- Mapbox access token

### Installation

1. **Clone the repository**
```bash
git clone https://github.com/YOUR_USERNAME/geoengine-pro.git
cd geoengine-pro
```

2. **Install dependencies**
```bash
npm run install:all
```

3. **Set up environment variables**
```bash
cp backend/.env.example backend/.env
cp frontend/.env.local.example frontend/.env.local
```
Edit both files with your actual credentials.

4. **Set up the database**
```bash
cd backend
npx prisma migrate dev --name init
npx prisma db seed
```

5. **Run the development servers**
```bash
cd ..
npm run dev
```

- Frontend: http://localhost:3000
- Backend API: http://localhost:4000
- API Docs: http://localhost:4000/api/docs

### Using Docker (Recommended for Quick Start)

```bash
docker-compose up -d
```

This spins up the entire stack including PostgreSQL, Redis, backend, and frontend.

## Environment Variables

### Backend (.env)
```env
NODE_ENV=development
PORT=4000
DATABASE_URL=postgresql://user:password@localhost:5432/geoengine_pro
REDIS_URL=redis://localhost:6379
JWT_SECRET=your-super-secret-jwt-key
JWT_EXPIRES_IN=7d
MAPBOX_ACCESS_TOKEN=pk.your_mapbox_token
CORS_ORIGIN=http://localhost:3000
```

### Frontend (.env.local)
```env
NEXT_PUBLIC_API_URL=http://localhost:4000
NEXT_PUBLIC_MAPBOX_TOKEN=pk.your_mapbox_token
NEXT_PUBLIC_APP_NAME=GeoEngine Pro
```

## API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/auth/register` | Create new account |
| POST | `/api/auth/login` | User login |
| GET | `/api/auth/me` | Get current user |
| GET | `/api/projects` | List all projects |
| POST | `/api/projects` | Create new project |
| GET | `/api/projects/:id` | Get project details |
| PUT | `/api/projects/:id` | Update project |
| DELETE | `/api/projects/:id` | Delete project |
| GET | `/api/layers` | List all layers |
| POST | `/api/layers` | Upload new layer |
| POST | `/api/analysis/buffer` | Buffer analysis |
| POST | `/api/analysis/intersect` | Intersection analysis |
| GET | `/api/export/:id` | Export project data |

## Scripts

| Command | Description |
|---------|-------------|
| `npm run dev` | Start both frontend and backend in dev mode |
| `npm run dev:backend` | Start only backend |
| `npm run dev:frontend` | Start only frontend |
| `npm run build` | Build frontend for production |
| `npm run start` | Start backend in production mode |
| `npm run install:all` | Install all dependencies |

## Testing

```bash
# Backend tests
cd backend && npm test

# Frontend tests
cd frontend && npm test

# E2E tests
cd frontend && npx cypress open
```

## Deployment

### Vercel (Frontend)
1. Push code to GitHub
2. Import repo in [Vercel](https://vercel.com)
3. Set environment variables
4. Deploy

### Railway/Render (Backend)
1. Connect GitHub repo
2. Set environment variables
3. Add PostgreSQL & Redis plugins
4. Deploy

### Docker (Self-Hosted)
```bash
docker-compose -f docker-compose.prod.yml up -d
```

## Contributing

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## License

This project is licensed under the MIT License.

## Support

For issues and feature requests, please use the [GitHub Issues](https://github.com/YOUR_USERNAME/geoengine-pro/issues) page.

---

Built with ❤️ for the geospatial community.
