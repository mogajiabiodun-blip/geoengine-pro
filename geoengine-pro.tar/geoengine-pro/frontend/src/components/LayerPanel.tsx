'use client';

import { useState } from 'react';
import { 
  Layers, 
  Eye, 
  EyeOff, 
  Sliders, 
  MoreHorizontal,
  ChevronUp,
  ChevronDown
} from 'lucide-react';

interface Layer {
  id: string;
  name: string;
  type: string;
  visible: boolean;
  opacity: number;
}

const sampleLayers: Layer[] = [
  { id: '1', name: 'Building Footprints', type: 'polygon', visible: true, opacity: 0.6 },
  { id: '2', name: 'Road Network', type: 'line', visible: true, opacity: 1 },
  { id: '3', name: 'Points of Interest', type: 'point', visible: true, opacity: 0.8 },
  { id: '4', name: 'Satellite Imagery', type: 'raster', visible: false, opacity: 1 },
];

export default function LayerPanel() {
  const [collapsed, setCollapsed] = useState(false);
  const [layers, setLayers] = useState<Layer[]>(sampleLayers);
  const [expandedLayer, setExpandedLayer] = useState<string | null>(null);

  const toggleVisibility = (id: string) => {
    setLayers(prev => prev.map(layer => 
      layer.id === id ? { ...layer, visible: !layer.visible } : layer
    ));
  };

  const updateOpacity = (id: string, opacity: number) => {
    setLayers(prev => prev.map(layer => 
      layer.id === id ? { ...layer, opacity } : layer
    ));
  };

  if (collapsed) {
    return (
      <button
        onClick={() => setCollapsed(false)}
        className="w-10 border-l border-gray-200 bg-white flex items-center justify-center hover:bg-gray-50 shrink-0"
        title="Expand layers"
      >
        <Layers className="w-5 h-5 text-gray-500" />
      </button>
    );
  }

  return (
    <div className="w-72 border-l border-gray-200 bg-white flex flex-col shrink-0">
      <div className="flex items-center justify-between px-4 py-3 border-b border-gray-100">
        <div className="flex items-center gap-2">
          <Layers className="w-5 h-5 text-gray-700" />
          <h2 className="font-semibold text-gray-900">Layers</h2>
        </div>
        <button
          onClick={() => setCollapsed(true)}
          className="p-1.5 rounded-lg hover:bg-gray-100 text-gray-500"
        >
          <ChevronUp className="w-4 h-4" />
        </button>
      </div>

      <div className="flex-1 overflow-y-auto p-3">
        <div className="space-y-2">
          {layers.map((layer) => (
            <div key={layer.id} className="border border-gray-200 rounded-lg bg-white">
              <div className="flex items-center justify-between px-3 py-2.5">
                <div className="flex items-center gap-2.5 min-w-0">
                  <button
                    onClick={() => toggleVisibility(layer.id)}
                    className={`shrink-0 ${layer.visible ? 'text-blue-600' : 'text-gray-400'}`}
                  >
                    {layer.visible ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
                  </button>
                  <span className={`text-sm truncate ${layer.visible ? 'text-gray-900' : 'text-gray-400'}`}>
                    {layer.name}
                  </span>
                </div>
                <div className="flex items-center gap-1 shrink-0">
                  <button
                    onClick={() => setExpandedLayer(expandedLayer === layer.id ? null : layer.id)}
                    className="p-1 rounded hover:bg-gray-100 text-gray-500"
                  >
                    <Sliders className="w-3.5 h-3.5" />
                  </button>
                  <button className="p-1 rounded hover:bg-gray-100 text-gray-500">
                    <MoreHorizontal className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              {expandedLayer === layer.id && (
                <div className="px-3 pb-3 border-t border-gray-100 pt-2">
                  <div className="space-y-3">
                    <div>
                      <div className="flex justify-between text-xs text-gray-500 mb-1">
                        <span>Opacity</span>
                        <span>{Math.round(layer.opacity * 100)}%</span>
                      </div>
                      <input
                        type="range"
                        min="0"
                        max="1"
                        step="0.1"
                        value={layer.opacity}
                        onChange={(e) => updateOpacity(layer.id, parseFloat(e.target.value))}
                        className="w-full h-1.5 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-blue-600"
                      />
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs text-gray-500">Type:</span>
                      <span className="text-xs text-gray-700 capitalize bg-gray-100 px-2 py-0.5 rounded">{layer.type}</span>
                    </div>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      <div className="p-3 border-t border-gray-100">
        <button className="w-full py-2 text-sm text-blue-600 hover:bg-blue-50 rounded-lg transition-colors font-medium">
          + Add Layer
        </button>
      </div>
    </div>
  );
}
