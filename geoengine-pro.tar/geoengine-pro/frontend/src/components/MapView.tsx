'use client';

import { useState, useCallback } from 'react';
import Map, { 
  NavigationControl, 
  ScaleControl, 
  FullscreenControl,
  AttributionControl,
} from 'react-map-gl';
import 'mapbox-gl/dist/mapbox-gl.css';

const MAPBOX_TOKEN = process.env.NEXT_PUBLIC_MAPBOX_TOKEN || '';

export default function MapView() {
  const [viewState, setViewState] = useState({
    longitude: 0,
    latitude: 20,
    zoom: 2,
    pitch: 0,
    bearing: 0,
  });

  const onMove = useCallback((evt: any) => {
    setViewState(evt.viewState);
  }, []);

  return (
    <div className="w-full h-full relative">
      <Map
        {...viewState}
        onMove={onMove}
        mapboxAccessToken={MAPBOX_TOKEN}
        mapStyle="mapbox://styles/mapbox/streets-v12"
        attributionControl={false}
        style={{ width: '100%', height: '100%' }}
      >
        <NavigationControl position="top-right" />
        <ScaleControl position="bottom-left" />
        <FullscreenControl position="top-right" />
        <AttributionControl position="bottom-right" />
      </Map>
      
      {/* Map Overlay Info */}
      <div className="absolute bottom-4 left-4 bg-white/90 backdrop-blur-sm rounded-lg px-3 py-2 text-xs shadow-md">
        <div className="text-gray-500">Zoom: {viewState.zoom.toFixed(2)}</div>
        <div className="text-gray-500">
          Lat: {viewState.latitude.toFixed(4)}, Lng: {viewState.longitude.toFixed(4)}
        </div>
      </div>
    </div>
  );
}
