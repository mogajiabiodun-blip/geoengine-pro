'use client';

import { useState } from 'react';
import Link from 'next/link';
import { 
  Map, 
  Layers, 
  BarChart3, 
  Settings, 
  User, 
  Menu,
  X,
  Globe
} from 'lucide-react';

export default function Navbar() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <nav className="bg-white border-b border-gray-200 h-14 flex items-center px-4 justify-between shrink-0 z-50">
      <div className="flex items-center gap-3">
        <div className="bg-blue-600 text-white p-1.5 rounded-lg">
          <Globe className="w-5 h-5" />
        </div>
        <Link href="/" className="text-lg font-bold text-gray-900 hover:text-blue-600 transition-colors">
          GeoEngine Pro
        </Link>
      </div>

      <div className="hidden md:flex items-center gap-1">
        <NavLink href="/" icon={<Map className="w-4 h-4" />} label="Map" active />
        <NavLink href="/projects" icon={<Layers className="w-4 h-4" />} label="Projects" />
        <NavLink href="/analytics" icon={<BarChart3 className="w-4 h-4" />} label="Analytics" />
        <NavLink href="/settings" icon={<Settings className="w-4 h-4" />} label="Settings" />
      </div>

      <div className="hidden md:flex items-center gap-3">
        <button className="text-sm text-gray-600 hover:text-gray-900 font-medium">
          Sign In
        </button>
        <button className="text-sm bg-blue-600 text-white px-4 py-1.5 rounded-lg hover:bg-blue-700 transition-colors font-medium">
          Get Started
        </button>
      </div>

      <button 
        className="md:hidden p-2 text-gray-600"
        onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
      >
        {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
      </button>

      {mobileMenuOpen && (
        <div className="absolute top-14 left-0 right-0 bg-white border-b border-gray-200 md:hidden shadow-lg">
          <div className="flex flex-col p-4 gap-2">
            <MobileNavLink href="/" icon={<Map className="w-4 h-4" />} label="Map" />
            <MobileNavLink href="/projects" icon={<Layers className="w-4 h-4" />} label="Projects" />
            <MobileNavLink href="/analytics" icon={<BarChart3 className="w-4 h-4" />} label="Analytics" />
            <MobileNavLink href="/settings" icon={<Settings className="w-4 h-4" />} label="Settings" />
            <hr className="my-2" />
            <button className="text-left text-sm text-gray-600 py-2 font-medium">
              Sign In
            </button>
            <button className="text-sm bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors font-medium">
              Get Started
            </button>
          </div>
        </div>
      )}
    </nav>
  );
}

function NavLink({ href, icon, label, active }: { href: string; icon: React.ReactNode; label: string; active?: boolean }) {
  return (
    <Link 
      href={href}
      className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-sm font-medium transition-colors ${
        active 
          ? 'bg-blue-50 text-blue-600' 
          : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
      }`}
    >
      {icon}
      {label}
    </Link>
  );
}

function MobileNavLink({ href, icon, label }: { href: string; icon: React.ReactNode; label: string }) {
  return (
    <Link 
      href={href}
      className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium text-gray-600 hover:bg-gray-50 hover:text-gray-900 transition-colors"
    >
      {icon}
      {label}
    </Link>
  );
}
