'use client';

import { useState } from 'react';
import { 
  Search, 
  Plus, 
  FolderOpen, 
  MapPin, 
  Ruler, 
  Share2, 
  Download,
  ChevronLeft,
  ChevronRight
} from 'lucide-react';

export default function Sidebar() {
  const [collapsed, setCollapsed] = useState(false);
  const [activeTool, setActiveTool] = useState<string | null>(null);

  const tools = [
    { id: 'search', icon: <Search className="w-5 h-5" />, label: 'Search', tooltip: 'Search locations' },
    { id: 'projects', icon: <FolderOpen className="w-5 h-5" />, label: 'Projects', tooltip: 'My projects' },
    { id: 'markers', icon: <MapPin className="w-5 h-5" />, label: 'Markers', tooltip: 'Add markers' },
    { id: 'measure', icon: <Ruler className="w-5 h-5" />, label: 'Measure', tooltip: 'Measure distance/area' },
    { id: 'share', icon: <Share2 className="w-5 h-5" />, label: 'Share', tooltip: 'Share map' },
    { id: 'export', icon: <Download className="w-5 h-5" />, label: 'Export', tooltip: 'Export data' },
  ];

  if (collapsed) {
    return (
      <div className="w-12 border-r border-gray-200 bg-white flex flex-col items-center py-3 gap-1 shrink-0">
        <button
          onClick={() => setCollapsed(false)}
          className="p-2 rounded-lg hover:bg-gray-100 text-gray-500 mb-2"
          title="Expand sidebar"
        >
          <ChevronRight className="w-4 h-4" />
        </button>
        {tools.map((tool) => (
          <button
            key={tool.id}
            onClick={() => setActiveTool(activeTool === tool.id ? null : tool.id)}
            className={`p-2.5 rounded-lg transition-colors ${
              activeTool === tool.id 
                ? 'bg-blue-50 text-blue-600' 
                : 'text-gray-500 hover:bg-gray-50 hover:text-gray-700'
            }`}
            title={tool.tooltip}
          >
            {tool.icon}
          </button>
        ))}
      </div>
    );
  }

  return (
    <div className="w-64 border-r border-gray-200 bg-white flex flex-col shrink-0">
      <div className="flex items-center justify-between px-4 py-3 border-b border-gray-100">
        <h2 className="font-semibold text-gray-900">Tools</h2>
        <button
          onClick={() => setCollapsed(true)}
          className="p-1.5 rounded-lg hover:bg-gray-100 text-gray-500"
          title="Collapse sidebar"
        >
          <ChevronLeft className="w-4 h-4" />
        </button>
      </div>

      <div className="p-3">
        <button className="w-full flex items-center justify-center gap-2 bg-blue-600 text-white py-2.5 rounded-lg hover:bg-blue-700 transition-colors font-medium text-sm mb-4">
          <Plus className="w-4 h-4" />
          New Project
        </button>

        <div className="space-y-1">
          {tools.map((tool) => (
            <button
              key={tool.id}
              onClick={() => setActiveTool(activeTool === tool.id ? null : tool.id)}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-colors ${
                activeTool === tool.id
                  ? 'bg-blue-50 text-blue-600 font-medium'
                  : 'text-gray-600 hover:bg-gray-50'
              }`}
            >
              {tool.icon}
              {tool.label}
            </button>
          ))}
        </div>
      </div>

      <div className="mt-auto p-4 border-t border-gray-100">
        <div className="bg-gray-50 rounded-lg p-3">
          <p className="text-xs text-gray-500 font-medium mb-1">Storage</p>
          <div className="w-full bg-gray-200 rounded-full h-2 mb-1">
            <div className="bg-blue-600 h-2 rounded-full" style={{ width: '35%' }} />
          </div>
          <p className="text-xs text-gray-500">350 MB / 1 GB used</p>
        </div>
      </div>
    </div>
  );
}
