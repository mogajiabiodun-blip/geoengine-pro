import { create } from 'zustand';

interface Project {
  id: string;
  name: string;
  description: string | null;
  centerLng: number;
  centerLat: number;
  zoom: number;
  isPublic: boolean;
  createdAt: string;
}

interface AppState {
  user: any | null;
  token: string | null;
  currentProject: Project | null;
  isSidebarOpen: boolean;
  isLayerPanelOpen: boolean;
  setUser: (user: any) => void;
  setToken: (token: string | null) => void;
  setCurrentProject: (project: Project | null) => void;
  toggleSidebar: () => void;
  toggleLayerPanel: () => void;
  logout: () => void;
}

export const useStore = create<AppState>((set) => ({
  user: null,
  token: typeof window !== 'undefined' ? localStorage.getItem('token') : null,
  currentProject: null,
  isSidebarOpen: true,
  isLayerPanelOpen: true,
  setUser: (user) => set({ user }),
  setToken: (token) => {
    if (token) {
      localStorage.setItem('token', token);
    } else {
      localStorage.removeItem('token');
    }
    set({ token });
  },
  setCurrentProject: (project) => set({ currentProject: project }),
  toggleSidebar: () => set((state) => ({ isSidebarOpen: !state.isSidebarOpen })),
  toggleLayerPanel: () => set((state) => ({ isLayerPanelOpen: !state.isLayerPanelOpen })),
  logout: () => {
    localStorage.removeItem('token');
    set({ user: null, token: null });
  },
}));
